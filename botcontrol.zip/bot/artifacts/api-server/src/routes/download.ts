import { Router } from "express";
import { createRequire } from "node:module";
import path from "path";
import fs from "fs";

const _req = createRequire(import.meta.url);
// eslint-disable-next-line @typescript-eslint/no-require-imports, @typescript-eslint/no-explicit-any
const archiver: typeof import("archiver") = _req("archiver") as any;

const router = Router();

const WORKSPACE_ROOT = path.resolve(process.cwd(), "..", "..");

const SKIP = new Set([
  "node_modules", "dist", ".git", ".tsbuildinfo", "pnpm-lock.yaml",
  ".replit", ".replit-artifact", ".agents", ".local", "bot-config.json",
]);

function addDir(archive: ReturnType<typeof archiver>, srcDir: string, destPrefix: string) {
  if (!fs.existsSync(srcDir)) return;
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    if (SKIP.has(entry.name)) continue;
    const full = path.join(srcDir, entry.name);
    const dest = `${destPrefix}/${entry.name}`;
    if (entry.isDirectory()) {
      addDir(archive, full, dest);
    } else {
      archive.file(full, { name: dest });
    }
  }
}

function addRootFiles(archive: ReturnType<typeof archiver>, prefix: string) {
  const files = ["package.json", "pnpm-workspace.yaml", "tsconfig.base.json", "tsconfig.json"];
  for (const f of files) {
    const full = path.join(WORKSPACE_ROOT, f);
    if (fs.existsSync(full)) {
      archive.file(full, { name: `${prefix}/${f}` });
    }
  }
}

const README = (section: "dashboard" | "bot") => {
  if (section === "dashboard") {
    return `# BotControl Dashboard

React + Vite frontend for the BotControl Minecraft bot.

## Setup
\`\`\`bash
pnpm install
pnpm --filter @workspace/dashboard run dev
\`\`\`

## Railway deployment
- Build command: \`pnpm --filter @workspace/dashboard run build\`
- Output: \`artifacts/dashboard/dist\`
- Environment: set BASE_PATH if not deployed at root
`;
  }
  return `# BotControl Bot / API Server

Express API server that runs the Mineflayer Minecraft bot.

## Setup
\`\`\`bash
pnpm install
pnpm --filter @workspace/api-server run dev
\`\`\`

## Railway deployment
- Start command: \`pnpm --filter @workspace/api-server run start\`
- Environment: PORT (set by Railway automatically)

## Default server
- Host: PowderedSMP.aternos.me
- Port: 21141

## Features
- Mines trees and ores with pathfinding
- Crafts items from gathered materials
- Defends against attackers (PvP)
- Anti-AFK bypass (random movement every 30 s)
- Auto-rejoin when server comes online
- Config persisted to bot-config.json
`;
};

const GITIGNORE = `node_modules/
dist/
.env
*.tsbuildinfo
bot-config.json
`;

const RAILWAY_JSON = JSON.stringify(
  {
    $schema: "https://railway.app/railway.schema.json",
    build: { builder: "NIXPACKS" },
    deploy: { startCommand: "pnpm --filter @workspace/api-server run start", restartPolicyType: "ON_FAILURE" },
  },
  null,
  2
);

router.get("/download", (_req, res) => {
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", 'attachment; filename="botcontrol.zip"');

  const archive = archiver("zip", { zlib: { level: 6 } });

  archive.on("error", (err) => {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  });

  archive.pipe(res);

  /* ── dashboard/ folder ── */
  addDir(archive, path.join(WORKSPACE_ROOT, "artifacts", "dashboard"), "dashboard/artifacts/dashboard");
  addDir(archive, path.join(WORKSPACE_ROOT, "lib"),                    "dashboard/lib");
  addRootFiles(archive, "dashboard");
  archive.append(README("dashboard"), { name: "dashboard/README.md" });
  archive.append(GITIGNORE, { name: "dashboard/.gitignore" });

  /* ── bot/ folder ── */
  addDir(archive, path.join(WORKSPACE_ROOT, "artifacts", "api-server"), "bot/artifacts/api-server");
  addDir(archive, path.join(WORKSPACE_ROOT, "lib"),                      "bot/lib");
  addRootFiles(archive, "bot");
  archive.append(README("bot"), { name: "bot/README.md" });
  archive.append(GITIGNORE, { name: "bot/.gitignore" });
  archive.append(RAILWAY_JSON, { name: "bot/railway.json" });

  archive.finalize();
});

export default router;
