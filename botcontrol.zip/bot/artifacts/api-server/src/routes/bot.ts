import { Router } from "express";
import { startBot, stopBot, restartBot, getBotStatus } from "../bot/bot-manager.js";
import { getConfig, updateConfig } from "../bot/config.js";
import { getLogs } from "../bot/activity-log.js";
import {
  UpdateBotConfigBody,
} from "@workspace/api-zod";

const router = Router();

router.get("/bot/status", (_req, res) => {
  res.json(getBotStatus());
});

router.post("/bot/start", (_req, res) => {
  const result = startBot();
  res.json(result);
});

router.post("/bot/stop", (_req, res) => {
  const result = stopBot();
  res.json(result);
});

router.post("/bot/restart", (_req, res) => {
  const result = restartBot();
  res.json(result);
});

router.get("/bot/config", (_req, res) => {
  res.json(getConfig());
});

router.put("/bot/config", (req, res) => {
  const parsed = UpdateBotConfigBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid config data" });
    return;
  }
  const current = getConfig();
  const updates = parsed.data;
  const updated = updateConfig({
    ...updates,
    activities: updates.activities
      ? {
          mine_trees: updates.activities.mine_trees ?? current.activities.mine_trees,
          mine_ores: updates.activities.mine_ores ?? current.activities.mine_ores,
          craft: updates.activities.craft ?? current.activities.craft,
          defend: updates.activities.defend ?? current.activities.defend,
        }
      : undefined,
  });
  res.json(updated);
});

router.get("/bot/logs", (_req, res) => {
  res.json(getLogs());
});

export default router;
