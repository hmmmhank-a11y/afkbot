import fs from "fs";
import path from "path";

export interface BotActivities {
  mine_trees: boolean;
  mine_ores: boolean;
  craft: boolean;
  defend: boolean;
}

export interface BotConfig {
  username: string;
  host: string;
  port: number;
  auto_join: boolean;
  anti_afk: boolean;
  color: string;
  activities: BotActivities;
}

const CONFIG_PATH = path.join(process.cwd(), "bot-config.json");

const DEFAULT_CONFIG: BotConfig = {
  username: "CraftBot",
  host: "PowderedSMP.aternos.me",
  port: 21141,
  auto_join: false,
  anti_afk: true,
  color: "#00ff88",
  activities: {
    mine_trees: true,
    mine_ores: true,
    craft: true,
    defend: true,
  },
};

function loadConfig(): BotConfig {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const raw = fs.readFileSync(CONFIG_PATH, "utf-8");
      return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
    }
  } catch {
    // ignore
  }
  return { ...DEFAULT_CONFIG };
}

function saveConfig(config: BotConfig): void {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), "utf-8");
  } catch {
    // ignore
  }
}

let _config: BotConfig = loadConfig();

export function getConfig(): BotConfig {
  return { ..._config };
}

export function updateConfig(updates: Partial<BotConfig>): BotConfig {
  _config = {
    ..._config,
    ...updates,
    activities: {
      ..._config.activities,
      ...(updates.activities ?? {}),
    },
  };
  saveConfig(_config);
  return { ..._config };
}
