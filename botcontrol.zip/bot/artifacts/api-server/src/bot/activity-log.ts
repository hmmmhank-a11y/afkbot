export interface LogEntry {
  id: number;
  timestamp: string;
  level: string;
  message: string;
}

let _logs: LogEntry[] = [];
let _nextId = 1;

export function addLog(level: "INFO" | "WARN" | "ACTION" | "ERROR", message: string): void {
  _logs.push({
    id: _nextId++,
    timestamp: new Date().toISOString(),
    level,
    message,
  });
  if (_logs.length > 150) {
    _logs = _logs.slice(-100);
  }
}

export function getLogs(): LogEntry[] {
  return [..._logs].reverse();
}

export function clearLogs(): void {
  _logs = [];
}
