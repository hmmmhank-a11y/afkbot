import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
// eslint-disable-next-line @typescript-eslint/no-require-imports
const mineflayer = require("mineflayer");
// eslint-disable-next-line @typescript-eslint/no-require-imports
const { pathfinder, Movements, goals } = require("mineflayer-pathfinder");
// eslint-disable-next-line @typescript-eslint/no-require-imports
const pvpPlugin = require("mineflayer-pvp").plugin;
import { getConfig } from "./config.js";
import { addLog } from "./activity-log.js";

const { GoalNear, GoalBlock } = goals;

interface BotState {
  online: boolean;
  startedAt: number | null;
  activity: string;
  health: number;
  food: number;
  position: { x: number; y: number; z: number } | null;
}

const state: BotState = {
  online: false,
  startedAt: null,
  activity: "Idle",
  health: 20,
  food: 20,
  position: null,
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let bot: any = null;
let activityInterval: ReturnType<typeof setInterval> | null = null;
let antiAfkInterval: ReturnType<typeof setInterval> | null = null;
let autoJoinInterval: ReturnType<typeof setInterval> | null = null;
let isMining = false;

function clearIntervals() {
  if (activityInterval) clearInterval(activityInterval);
  if (antiAfkInterval) clearInterval(antiAfkInterval);
  activityInterval = null;
  antiAfkInterval = null;
}

function getOreBlockIds(mcData: any): number[] {
  const oreNames = [
    "coal_ore", "iron_ore", "gold_ore", "diamond_ore",
    "emerald_ore", "lapis_ore", "redstone_ore",
    "deepslate_coal_ore", "deepslate_iron_ore", "deepslate_gold_ore",
    "deepslate_diamond_ore", "deepslate_emerald_ore",
    "deepslate_lapis_ore", "deepslate_redstone_ore",
    "ancient_debris", "nether_quartz_ore", "nether_gold_ore",
  ];
  return oreNames
    .filter((n) => mcData.blocksByName[n])
    .map((n) => mcData.blocksByName[n].id);
}

function getLogBlockIds(mcData: any): number[] {
  const logNames = [
    "oak_log", "birch_log", "spruce_log", "jungle_log",
    "acacia_log", "dark_oak_log", "mangrove_log",
    "oak_wood", "birch_wood", "spruce_wood",
  ];
  return logNames
    .filter((n) => mcData.blocksByName[n])
    .map((n) => mcData.blocksByName[n].id);
}

async function mineBlock(target: any) {
  if (!bot || isMining) return;
  const config = getConfig();
  try {
    isMining = true;
    const pos = target.position;
    const movements = new Movements(bot);
    bot.pathfinder.setMovements(movements);
    await bot.pathfinder.goto(new GoalNear(pos.x, pos.y, pos.z, 1));
    if (!bot.canDigBlock(target)) {
      isMining = false;
      return;
    }
    await bot.dig(target);
    if (config.activities.craft) {
      await tryCraft();
    }
  } catch {
    // can't reach, skip
  } finally {
    isMining = false;
  }
}

async function tryCraft() {
  if (!bot) return;
  try {
    const mcData = bot.registry;
    if (!mcData.itemsByName) return;

    const logItem = bot.inventory.items().find((i: any) =>
      ["oak_log", "birch_log", "spruce_log", "jungle_log", "acacia_log", "dark_oak_log"].some(
        (name) => mcData.itemsByName[name] && mcData.itemsByName[name].id === i.type
      )
    );

    if (logItem && logItem.count >= 1) {
      const plankId = mcData.itemsByName["oak_planks"]?.id;
      if (!plankId) return;
      const recipe = bot.recipesFor(plankId, null, 1, null)[0];
      if (recipe) {
        await bot.craft(recipe, 4, null);
        addLog("ACTION", "Crafted oak planks from logs");
      }
    }
  } catch {
    // crafting failed, ignore
  }
}

async function runMiningLoop() {
  if (!bot || isMining) return;
  const config = getConfig();
  const mcData = bot.registry;
  if (!mcData) return;

  const oreIds = getOreBlockIds(mcData);
  const logIds = getLogBlockIds(mcData);

  let target = null;

  if (config.activities.mine_ores) {
    target = bot.findBlock({ matching: oreIds, maxDistance: 20 });
    if (target) {
      const oreName = mcData.blocks[target.type]?.name ?? "ore";
      state.activity = `Mining ${oreName.replace("_", " ")}`;
      addLog("ACTION", `Mining ${oreName.replace(/_/g, " ")} at ${Math.round(target.position.x)}, ${Math.round(target.position.y)}, ${Math.round(target.position.z)}`);
      await mineBlock(target);
      return;
    }
  }

  if (config.activities.mine_trees) {
    target = bot.findBlock({ matching: logIds, maxDistance: 20 });
    if (target) {
      const logName = mcData.blocks[target.type]?.name ?? "log";
      state.activity = `Chopping ${logName.replace("_", " ")}`;
      addLog("ACTION", `Chopping ${logName.replace(/_/g, " ")} at ${Math.round(target.position.x)}, ${Math.round(target.position.y)}, ${Math.round(target.position.z)}`);
      await mineBlock(target);
      return;
    }
  }

  state.activity = "Exploring";
}

function setupAntiAfk() {
  if (antiAfkInterval) clearInterval(antiAfkInterval);
  antiAfkInterval = setInterval(() => {
    if (!bot || !state.online) return;
    const config = getConfig();
    if (!config.anti_afk) return;
    try {
      bot.setControlState("jump", true);
      setTimeout(() => {
        if (bot) bot.setControlState("jump", false);
      }, 200);
      bot.look(Math.random() * Math.PI * 2, (Math.random() - 0.5) * 0.5, false);
    } catch {
      // ignore
    }
  }, 30000);
}

function setupActivityLoop() {
  if (activityInterval) clearInterval(activityInterval);
  activityInterval = setInterval(() => {
    if (!bot || !state.online || isMining) return;
    runMiningLoop().catch(() => {});
  }, 5000);
}

function setupDefend() {
  if (!bot) return;
  bot.on("entityHurt", (entity: any) => {
    if (!state.online) return;
    const config = getConfig();
    if (!config.activities.defend) return;
    if (entity !== bot.entity) return;
    // Find the closest non-passive entity that might have attacked us
    const attacker = bot.nearestEntity((e: any) =>
      e.type === "player" || e.type === "mob"
    );
    if (attacker) {
      state.activity = `Defending against ${attacker.username ?? attacker.name ?? "entity"}`;
      addLog("WARN", `Defending! Attacking ${attacker.username ?? attacker.name ?? "entity"}`);
      try {
        bot.pvp.attack(attacker);
        setTimeout(() => {
          if (bot) bot.pvp.stop();
        }, 5000);
      } catch {
        // pvp may not be ready
      }
    }
  });

  bot.on("physicsTick", () => {
    if (!state.online || !bot) return;
    try {
      state.health = bot.health ?? 20;
      state.food = bot.food ?? 20;
      state.position = bot.entity?.position
        ? { x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z }
        : null;
    } catch {
      // ignore
    }
  });
}

function createBot() {
  const config = getConfig();
  addLog("INFO", `Connecting to ${config.host}:${config.port} as ${config.username}...`);

  bot = mineflayer.createBot({
    host: config.host,
    port: config.port,
    username: config.username,
    auth: "offline",
  });

  bot.loadPlugin(pathfinder);
  bot.loadPlugin(pvpPlugin);

  bot.once("spawn", () => {
    state.online = true;
    state.startedAt = Date.now();
    state.activity = "Idle";
    addLog("INFO", `Bot spawned on ${config.host}:${config.port} as ${config.username}`);
    setupDefend();
    setupActivityLoop();
    setupAntiAfk();
  });

  bot.on("health", () => {
    if (bot) {
      state.health = bot.health ?? 20;
      state.food = bot.food ?? 20;
    }
  });

  bot.on("kicked", (reason: string) => {
    addLog("WARN", `Bot was kicked: ${reason}`);
    handleDisconnect();
  });

  bot.on("error", (err: Error) => {
    addLog("ERROR", `Connection error: ${err.message}`);
    handleDisconnect();
  });

  bot.on("end", () => {
    addLog("INFO", "Bot disconnected from server");
    handleDisconnect();
    tryAutoJoin();
  });
}

function handleDisconnect() {
  state.online = false;
  state.startedAt = null;
  state.activity = "Offline";
  isMining = false;
  clearIntervals();
  bot = null;
}

function tryAutoJoin() {
  const config = getConfig();
  if (!config.auto_join) return;
  addLog("INFO", "Auto-join enabled — will retry connection in 30 seconds");
  if (autoJoinInterval) clearInterval(autoJoinInterval);
  autoJoinInterval = setInterval(() => {
    if (!state.online) {
      addLog("INFO", "Auto-join: attempting to reconnect...");
      createBot();
      clearInterval(autoJoinInterval!);
      autoJoinInterval = null;
    }
  }, 30000);
}

export function startBot(): { success: boolean; message: string } {
  if (state.online) {
    return { success: false, message: "Bot is already running" };
  }
  if (bot) {
    return { success: false, message: "Bot is connecting..." };
  }
  try {
    createBot();
    return { success: true, message: "Bot is connecting..." };
  } catch (err: any) {
    return { success: false, message: `Failed to start: ${err.message}` };
  }
}

export function stopBot(): { success: boolean; message: string } {
  if (!bot && !state.online) {
    return { success: false, message: "Bot is not running" };
  }
  try {
    clearIntervals();
    if (autoJoinInterval) {
      clearInterval(autoJoinInterval);
      autoJoinInterval = null;
    }
    if (bot) {
      bot.quit("Stopped by dashboard");
      bot = null;
    }
    state.online = false;
    state.startedAt = null;
    state.activity = "Offline";
    isMining = false;
    addLog("INFO", "Bot stopped by dashboard");
    return { success: true, message: "Bot stopped" };
  } catch (err: any) {
    return { success: false, message: `Failed to stop: ${err.message}` };
  }
}

export function restartBot(): { success: boolean; message: string } {
  stopBot();
  setTimeout(() => {
    createBot();
  }, 2000);
  addLog("INFO", "Bot restarting...");
  return { success: true, message: "Bot is restarting..." };
}

export function getBotStatus() {
  const config = getConfig();
  const uptimeSeconds = state.startedAt
    ? Math.floor((Date.now() - state.startedAt) / 1000)
    : 0;
  return {
    online: state.online,
    username: config.username,
    uptime_seconds: uptimeSeconds,
    activity: state.activity,
    health: state.health,
    food: state.food,
    host: config.host,
    port: config.port,
    position: state.position ?? undefined,
  };
}
