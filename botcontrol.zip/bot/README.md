# BotControl Bot / API Server

Express API server that runs the Mineflayer Minecraft bot.

## Setup
```bash
pnpm install
pnpm --filter @workspace/api-server run dev
```

## Railway deployment
- Start command: `pnpm --filter @workspace/api-server run start`
- Environment: PORT (set by Railway automatically)

## Default server
- Host: PowderedSMP.aternos.me
- Port: 21141

## Features
- Mines trees and ores with pathfinding
- Crafts items from gathered materials
- Defends against attackers (PvP)
- Anti-AFK bypass (random movement every 30 s)
- Auto-rejoin when server comes online
- Config persisted to bot-config.json
