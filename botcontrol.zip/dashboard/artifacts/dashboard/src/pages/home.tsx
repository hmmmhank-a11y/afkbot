import React, { useState, useEffect, useRef } from "react";
import { format } from "date-fns";
import {
  Settings,
  Power,
  Square,
  Download,
  ShieldAlert,
  Pickaxe,
  Hammer,
  Activity,
  Server,
  RefreshCw,
  MapPin,
} from "lucide-react";
import {
  useGetBotStatus,
  useGetBotConfig,
  useUpdateBotConfig,
  useStartBot,
  useStopBot,
  useRestartBot,
  useGetBotLogs,
  getGetBotStatusQueryKey,
  getGetBotConfigQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

/* ── Uptime counter ── */
function UptimeCounter({ seconds, active }: { seconds: number; active: boolean }) {
  const [local, setLocal] = useState(seconds);

  useEffect(() => { setLocal(seconds); }, [seconds]);

  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => setLocal((p) => p + 1), 1000);
    return () => clearInterval(t);
  }, [active]);

  const hrs  = Math.floor(local / 3600);
  const mins = Math.floor((local % 3600) / 60);
  const secs = local % 60;
  const pad  = (n: number) => n.toString().padStart(2, "0");

  return (
    <div className="flex items-center gap-1 font-display font-bold text-2xl tracking-widest">
      {[pad(hrs), pad(mins), pad(secs)].map((seg, i) => (
        <React.Fragment key={i}>
          <span
            className="text-white tabular-nums"
            style={{ textShadow: "0 0 14px rgba(0,255,136,0.5)" }}
          >
            {seg}
          </span>
          {i < 2 && <span className="text-primary/60 animate-pulse">:</span>}
        </React.Fragment>
      ))}
    </div>
  );
}

/* ── Segmented bar ── */
function SegmentBar({
  value,
  max = 20,
  color,
  label,
}: {
  value: number;
  max?: number;
  color: string;
  label: string;
}) {
  const filled = Math.round((value / max) * 10);
  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-medium">{label}</span>
        <span className="font-mono text-xs font-bold" style={{ color }}>
          {Math.round(value)}/{max}
        </span>
      </div>
      <div className="flex gap-[3px]">
        {Array.from({ length: 10 }).map((_, i) => (
          <div
            key={i}
            className="flex-1 h-2 rounded-[2px] transition-all duration-500"
            style={{
              background: i < filled ? color : "rgba(255,255,255,0.07)",
              boxShadow: i < filled ? `0 0 6px ${color}66` : "none",
            }}
          />
        ))}
      </div>
    </div>
  );
}

/* ── XYZ coordinate block ── */
function CoordBlock({ pos }: { pos?: { x: number; y: number; z: number } }) {
  if (!pos) {
    return (
      <div className="flex gap-4 text-muted-foreground/40 font-mono text-xs">
        <span>X —</span><span>Y —</span><span>Z —</span>
      </div>
    );
  }
  const fmt = (n: number) => n.toFixed(1).padStart(8);
  return (
    <div className="flex gap-3">
      {[
        { label: "X", val: fmt(pos.x), color: "#ff5555" },
        { label: "Y", val: fmt(pos.y), color: "#55ff55" },
        { label: "Z", val: fmt(pos.z), color: "#5599ff" },
      ].map(({ label, val, color }) => (
        <div key={label} className="flex items-baseline gap-1">
          <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color }}>
            {label}
          </span>
          <span
            className="coord-val font-mono text-xs text-white/90"
            style={{ textShadow: `0 0 8px ${color}66` }}
          >
            {val}
          </span>
        </div>
      ))}
    </div>
  );
}

/* ── Activity toggle row ── */
function ActivityRow({
  icon: Icon,
  label,
  color,
  checked,
  onChange,
}: {
  icon: React.ElementType;
  label: string;
  color: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between px-4 py-3 rounded-lg bg-white/[0.025] border border-white/[0.06] hover:bg-white/[0.04] transition-all duration-200 group">
      <div className="flex items-center gap-3">
        <div
          className="w-8 h-8 rounded-md flex items-center justify-center"
          style={{ background: `${color}18`, border: `1px solid ${color}40` }}
        >
          <Icon className="w-4 h-4" style={{ color }} />
        </div>
        <span className="font-medium text-sm text-white/90">{label}</span>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

/* ── Main page ── */
export default function Home() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: status } = useGetBotStatus({ query: { refetchInterval: 2000 } });
  const { data: config } = useGetBotConfig({ query: { refetchInterval: 5000 } });
  const { data: logs } = useGetBotLogs({ query: { refetchInterval: 3000 } });

  const updateConfig = useUpdateBotConfig();
  const startBot     = useStartBot();
  const stopBot      = useStopBot();
  const restartBot   = useRestartBot();

  const [color, setColor]       = useState("#00ff88");
  const [username, setUsername] = useState("");
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (config) {
      setColor(config.color || "#00ff88");
      setUsername(config.username || "");
    }
  }, [config]);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  const handleUpdateConfig = (updates: Record<string, unknown>) => {
    updateConfig.mutate(
      { data: updates },
      {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetBotConfigQueryKey() }),
        onError:   () => toast({ title: "Failed to update config", variant: "destructive" }),
      }
    );
  };

  const handleStart = () =>
    startBot.mutate(undefined, {
      onSuccess: () => {
        toast({ title: "Bot connecting..." });
        queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
      },
    });

  const handleStop = () =>
    stopBot.mutate(undefined, {
      onSuccess: () => {
        toast({ title: "Bot stopped" });
        queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
      },
    });

  const handleRestart = () =>
    restartBot.mutate(undefined, {
      onSuccess: () => {
        toast({ title: "Bot restarting..." });
        queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
      },
    });

  const isOnline = status?.online ?? false;

  return (
    <div className="relative min-h-screen text-foreground selection:bg-primary/30">
      {/* Animated gradient background */}
      <div className="bg-animated" />

      {/* Content */}
      <div className="relative z-10 flex flex-col min-h-screen">

        {/* ── Top bar ── */}
        <header className="sticky top-0 z-50 border-b border-white/[0.06] bg-black/50 backdrop-blur-xl">
          <div className="container max-w-6xl mx-auto h-16 flex items-center justify-between px-4">

            {/* Logo */}
            <div className="flex items-center gap-3">
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center"
                style={{
                  background: "rgba(0,255,136,0.12)",
                  border: "1px solid rgba(0,255,136,0.35)",
                  boxShadow: "0 0 16px rgba(0,255,136,0.15)",
                }}
              >
                <Activity className="w-5 h-5 text-primary" />
              </div>
              <h1 className="title-shimmer text-xl tracking-wide">BotControl</h1>
            </div>

            {/* Uptime */}
            <div className="flex flex-col items-center">
              <span className="text-[9px] text-muted-foreground font-medium uppercase tracking-[0.2em] mb-0.5">
                Session Uptime
              </span>
              {isOnline ? (
                <UptimeCounter seconds={status?.uptime_seconds ?? 0} active={isOnline} />
              ) : (
                <div
                  className="font-display font-bold text-2xl tracking-widest text-white/20"
                  style={{ textShadow: "none" }}
                >
                  00:00:00
                </div>
              )}
            </div>

            {/* Settings gear */}
            <Drawer>
              <DrawerTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full hover:bg-white/[0.06] hover:text-white text-white/60 transition-all"
                >
                  <Settings className="w-5 h-5" />
                </Button>
              </DrawerTrigger>
              <DrawerContent className="border-white/10 text-foreground" style={{ background: "#0a0c14" }}>
                <div className="max-w-md mx-auto w-full p-6">
                  <DrawerHeader className="px-0">
                    <DrawerTitle className="font-display text-xl tracking-wide text-white">
                      Bot Settings
                    </DrawerTitle>
                  </DrawerHeader>
                  <div className="space-y-6 py-4">
                    <div className="flex items-center justify-between p-4 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                      <div className="space-y-0.5">
                        <Label className="text-sm font-semibold text-white">Auto-join Server</Label>
                        <p className="text-xs text-muted-foreground">Instantly rejoin when server opens</p>
                      </div>
                      <Switch
                        checked={config?.auto_join ?? false}
                        onCheckedChange={(c) => handleUpdateConfig({ auto_join: c })}
                      />
                    </div>
                    <Separator className="bg-white/[0.06]" />
                    <div className="flex items-center justify-between p-4 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                      <div className="space-y-0.5">
                        <Label className="text-sm font-semibold text-white">Anti-AFK Bypass</Label>
                        <p className="text-xs text-muted-foreground">Randomly move to bypass AFK detection</p>
                      </div>
                      <Switch
                        checked={config?.anti_afk ?? false}
                        onCheckedChange={(c) => handleUpdateConfig({ anti_afk: c })}
                      />
                    </div>
                  </div>
                </div>
              </DrawerContent>
            </Drawer>
          </div>
        </header>

        {/* ── Main content ── */}
        <main className="container max-w-6xl mx-auto px-4 py-6 flex flex-col gap-5 flex-1">

          {/* ── Status + Identity row ── */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

            {/* Server status card */}
            <Card
              className="card-lift lg:col-span-2 relative overflow-hidden border-white/[0.06]"
              style={{ background: "rgba(6,8,16,0.8)" }}
            >
              <div className="card-scan" />
              <div
                className="absolute inset-0 opacity-30"
                style={{
                  background:
                    "radial-gradient(ellipse 80% 60% at 0% 50%, rgba(0,255,136,0.06) 0%, transparent 70%)",
                }}
              />
              <CardContent className="p-5 relative z-10">
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">

                  {/* Online indicator */}
                  <div className="flex items-center gap-4">
                    <div className="relative flex items-center justify-center">
                      {isOnline ? (
                        <>
                          <div className="absolute w-10 h-10 rounded-full bg-primary/10 animate-ping" />
                          <div
                            className="w-5 h-5 rounded-full bg-primary dot-online"
                          />
                        </>
                      ) : (
                        <div className="w-5 h-5 rounded-full bg-destructive/40" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2 mb-0.5">
                        <span
                          className="font-display text-xs font-bold tracking-[0.15em] uppercase"
                          style={{ color: isOnline ? "#00ff88" : "#ff5555" }}
                        >
                          {isOnline ? "ONLINE" : "OFFLINE"}
                        </span>
                        <Badge
                          className="text-[9px] px-2 py-0 border-0 font-medium"
                          style={{
                            background: isOnline ? "rgba(0,255,136,0.12)" : "rgba(255,85,85,0.12)",
                            color: isOnline ? "#00ff88" : "#ff6666",
                          }}
                        >
                          {isOnline ? (status?.activity ?? "Idle") : "Disconnected"}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Server className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="font-mono text-sm text-white/80 tracking-tight">
                          {config?.host ?? "---"}:{config?.port ?? "---"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Divider */}
                  <div className="hidden sm:block w-px h-14 bg-white/[0.06]" />

                  {/* Stats */}
                  <div className="flex-1 space-y-3 w-full">
                    <SegmentBar value={status?.health ?? 0} color="#ff5555" label="Health" />
                    <SegmentBar value={status?.food ?? 0} color="#ffaa44" label="Food" />
                  </div>

                  {/* Divider */}
                  <div className="hidden sm:block w-px h-14 bg-white/[0.06]" />

                  {/* XYZ coords */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <MapPin className="w-3 h-3 text-muted-foreground" />
                      <span className="text-[9px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
                        Position
                      </span>
                    </div>
                    <CoordBlock pos={status?.position} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Identity card */}
            <Card
              className="card-lift relative overflow-hidden border-white/[0.06]"
              style={{ background: "rgba(6,8,16,0.8)" }}
            >
              <CardContent className="p-5 h-full flex flex-col">
                <h2 className="font-display text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground mb-4">
                  Bot Identity
                </h2>
                <div className="space-y-4 flex-1">
                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-widest text-white/40">Username</Label>
                    <Input
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      onBlur={() => handleUpdateConfig({ username })}
                      className="h-9 bg-white/[0.04] border-white/[0.08] focus-visible:ring-primary font-mono text-sm"
                      placeholder="CraftBot"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[10px] uppercase tracking-widest text-white/40">Accent Color</Label>
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <input
                          type="color"
                          value={color}
                          onChange={(e) => setColor(e.target.value)}
                          onBlur={() => handleUpdateConfig({ color })}
                          className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0 p-0.5"
                          style={{ outline: `2px solid ${color}60` }}
                        />
                      </div>
                      <div className="space-y-0.5">
                        <div
                          className="font-mono text-sm font-bold"
                          style={{ color, textShadow: `0 0 12px ${color}80` }}
                        >
                          {color.toUpperCase()}
                        </div>
                        <div className="text-[10px] text-muted-foreground">Click to change</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ── Control buttons ── */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={handleStart}
              disabled={isOnline || startBot.isPending}
              className="btn-start h-20 flex items-center justify-center gap-3 rounded-xl text-base font-display font-bold tracking-widest transition-all duration-250 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: "rgba(0,255,136,0.08)",
                border: "1px solid rgba(0,255,136,0.25)",
                color: "#00ff88",
              }}
            >
              <Power className="w-5 h-5" />
              START BOT
            </button>

            <button
              onClick={handleStop}
              disabled={!isOnline || stopBot.isPending}
              className="btn-stop h-20 flex items-center justify-center gap-3 rounded-xl text-base font-display font-bold tracking-widest transition-all duration-250 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: "rgba(255,42,74,0.08)",
                border: "1px solid rgba(255,42,74,0.25)",
                color: "#ff2a4a",
              }}
            >
              <Square className="w-5 h-5" />
              STOP BOT
            </button>

            <button
              onClick={handleRestart}
              disabled={restartBot.isPending}
              className="btn-restart h-20 flex items-center justify-center gap-3 rounded-xl text-base font-display font-bold tracking-widest transition-all duration-250 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{
                background: "rgba(251,191,36,0.08)",
                border: "1px solid rgba(251,191,36,0.25)",
                color: "#fbbf24",
              }}
            >
              <RefreshCw className="w-5 h-5" />
              RESTART
            </button>
          </div>

          {/* ── Activities + Logs ── */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 flex-1">

            {/* Activities */}
            <Card
              className="border-white/[0.06] relative overflow-hidden"
              style={{ background: "rgba(6,8,16,0.8)" }}
            >
              <CardContent className="p-5 flex flex-col gap-3 h-full">
                <h2 className="font-display text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
                  Activities
                </h2>
                <div className="space-y-2">
                  <ActivityRow
                    icon={TreesIcon}
                    label="Mine Trees"
                    color="#4ade80"
                    checked={config?.activities?.mine_trees ?? false}
                    onChange={(c) => handleUpdateConfig({ activities: { mine_trees: c } })}
                  />
                  <ActivityRow
                    icon={Pickaxe}
                    label="Mine Ores"
                    color="#38bdf8"
                    checked={config?.activities?.mine_ores ?? false}
                    onChange={(c) => handleUpdateConfig({ activities: { mine_ores: c } })}
                  />
                  <ActivityRow
                    icon={Hammer}
                    label="Craft Items"
                    color="#fbbf24"
                    checked={config?.activities?.craft ?? false}
                    onChange={(c) => handleUpdateConfig({ activities: { craft: c } })}
                  />
                  <ActivityRow
                    icon={ShieldAlert}
                    label="Defend Self"
                    color="#f87171"
                    checked={config?.activities?.defend ?? false}
                    onChange={(c) => handleUpdateConfig({ activities: { defend: c } })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Live activity feed */}
            <Card
              className="border-white/[0.06] lg:col-span-2 flex flex-col"
              style={{ background: "rgba(6,8,16,0.8)", minHeight: "320px" }}
            >
              <CardContent className="p-0 flex flex-col h-full overflow-hidden">
                <div className="px-5 py-3.5 border-b border-white/[0.06] flex items-center gap-2">
                  <Activity className="w-3.5 h-3.5 text-primary" />
                  <h2 className="font-display text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
                    Live Activity Feed
                  </h2>
                  <div className="ml-auto flex items-center gap-1.5">
                    <div
                      className="w-1.5 h-1.5 rounded-full animate-pulse"
                      style={{ background: "#00ff88", boxShadow: "0 0 6px #00ff88" }}
                    />
                    <span className="text-[9px] text-primary/70 font-mono">LIVE</span>
                  </div>
                </div>
                <ScrollArea className="flex-1 px-4 py-3">
                  {!logs || logs.length === 0 ? (
                    <div className="flex items-center justify-center h-24 text-muted-foreground/40 text-xs font-mono">
                      No activity yet — start the bot
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {logs.map((log) => (
                        <div key={log.id} className="log-entry flex gap-3 group">
                          <span className="font-mono text-[10px] text-muted-foreground/60 shrink-0 pt-px whitespace-nowrap">
                            {format(new Date(log.timestamp), "HH:mm:ss")}
                          </span>
                          <span
                            className="font-display text-[9px] font-bold uppercase tracking-widest shrink-0 pt-px w-14"
                            style={{
                              color:
                                log.level === "INFO"    ? "#00ff88" :
                                log.level === "WARN"    ? "#fbbf24" :
                                log.level === "ERROR"   ? "#f87171" :
                                log.level === "ACTION"  ? "#38bdf8" : "#aaa",
                            }}
                          >
                            {log.level}
                          </span>
                          <span className="font-mono text-xs text-white/70 group-hover:text-white/90 transition-colors break-all flex-1">
                            {log.message}
                          </span>
                        </div>
                      ))}
                      <div ref={logsEndRef} />
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* ── Footer: download ── */}
          <div className="flex items-center justify-between py-3 border-t border-white/[0.05]">
            <span className="text-[10px] text-muted-foreground/40 font-mono">
              BotControl v1.0 · PowderedSMP.aternos.me:{config?.port ?? 21141}
            </span>
            <a
              href={`${import.meta.env.BASE_URL.replace(/\/$/, "")}/api/download`}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-display font-bold uppercase tracking-widest transition-all duration-200 border"
              style={{
                background: "rgba(0,255,136,0.06)",
                borderColor: "rgba(0,255,136,0.2)",
                color: "#00ff88",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow = "0 0 20px rgba(0,255,136,0.2)";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,255,136,0.5)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow = "";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,255,136,0.2)";
              }}
            >
              <Download className="w-3.5 h-3.5" />
              Download ZIP (Dashboard + Bot)
            </a>
          </div>
        </main>
      </div>
    </div>
  );
}

/* ── Tree icon ── */
function TreesIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 22v-8" />
      <path d="m17 14-5-4-5 4" />
      <path d="m15 10-3-4-3 4" />
      <path d="M8 6h8l-4-5z" />
    </svg>
  );
}
