# BotControl Dashboard

React + Vite frontend for the BotControl Minecraft bot.

## Setup
```bash
pnpm install
pnpm --filter @workspace/dashboard run dev
```

## Railway deployment
- Build command: `pnpm --filter @workspace/dashboard run build`
- Output: `artifacts/dashboard/dist`
- Environment: set BASE_PATH if not deployed at root
